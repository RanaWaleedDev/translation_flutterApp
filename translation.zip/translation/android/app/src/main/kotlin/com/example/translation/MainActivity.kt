package com.example.translation

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
